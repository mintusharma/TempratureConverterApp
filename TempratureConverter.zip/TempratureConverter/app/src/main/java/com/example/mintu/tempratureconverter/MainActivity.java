package com.example.mintu.tempratureconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

   private EditText temprature;
    RadioGroup rg;
    boolean cel=true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        temprature = (EditText) findViewById(R.id.inputdata);

        Button btn = (Button) findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temprature.setText("");
            }
        });
    }
    public void convertTemp(View view){
    switch (view.getId()){
        case R.id.button1:
            RadioButton rb1=(RadioButton)findViewById(R.id.celcious);
            RadioButton rb2=(RadioButton)findViewById(R.id.ferhanite);

            if(temprature.getText().length()==0){
                Toast.makeText(this, "Please enter a valid number",
                        Toast.LENGTH_LONG).show();
                return;
            }
            float inputValue=Float.parseFloat(temprature.getText().toString());
            if(rb1.isChecked()){
                temprature.setText(String.valueOf(ConvertUtil.convertFahrenheitToCelsius(inputValue)));
                rb1.setChecked(false);
                rb2.setChecked(true);
            }else{
                temprature.setText(String.valueOf(ConvertUtil.convertCelsiusToFahrenheit(inputValue)));
                rb1.setChecked(false);
                rb2.setChecked(true);
            }
            break;
    }

    }


}
